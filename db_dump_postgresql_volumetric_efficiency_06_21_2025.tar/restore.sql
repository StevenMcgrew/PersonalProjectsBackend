--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5 (Ubuntu 14.5-1.pgdg20.04+1)
-- Dumped by pg_dump version 14.5 (Ubuntu 14.5-1.pgdg20.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ve;
--
-- Name: ve; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE ve WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE ve OWNER TO postgres;

\connect ve

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: calculations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.calculations (
    id integer NOT NULL,
    created_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    year character(4) NOT NULL,
    make character varying(40) NOT NULL,
    model character varying(40) NOT NULL,
    engine character varying(5) NOT NULL,
    condition character varying(6) NOT NULL,
    comments character varying(300) NOT NULL,
    maf_units character varying(4) NOT NULL,
    temp_units character(2) NOT NULL,
    elevation_units character varying(2) NOT NULL,
    rpm numeric NOT NULL,
    maf numeric NOT NULL,
    air_temp numeric NOT NULL,
    elevation numeric NOT NULL,
    expected_maf numeric,
    maf_diff numeric,
    ve numeric NOT NULL
);


ALTER TABLE public.calculations OWNER TO postgres;

--
-- Name: calculations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.calculations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.calculations_id_seq OWNER TO postgres;

--
-- Name: calculations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.calculations_id_seq OWNED BY public.calculations.id;


--
-- Name: calculations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calculations ALTER COLUMN id SET DEFAULT nextval('public.calculations_id_seq'::regclass);


--
-- Data for Name: calculations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.calculations (id, created_on, year, make, model, engine, condition, comments, maf_units, temp_units, elevation_units, rpm, maf, air_temp, elevation, expected_maf, maf_diff, ve) FROM stdin;
\.
COPY public.calculations (id, created_on, year, make, model, engine, condition, comments, maf_units, temp_units, elevation_units, rpm, maf, air_temp, elevation, expected_maf, maf_diff, ve) FROM '$$PATH$$/3280.dat';

--
-- Name: calculations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.calculations_id_seq', 1009, true);


--
-- Name: calculations calculations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calculations
    ADD CONSTRAINT calculations_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

